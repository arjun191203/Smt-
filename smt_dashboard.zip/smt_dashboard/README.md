# SMT Line Dashboard

A live dashboard for your SMT lines: day plan vs actual, hourly output for
all lines, and per-line detail (mounter, AOI, hourly UPH, solder paste
timing, stencil cleaning timing) — all driven from one Excel file.

```
smt_dashboard/
├── app.py                          <- the web server (Python/Flask)
├── build_excel.py                  <- run once to (re)create a blank template
├── requirements.txt
├── data/
│   └── SMT_Dashboard_Data.xlsx     <- YOU EDIT THIS DAILY
├── templates/index.html
└── static/style.css, dashboard.js
```

## 1. One-time setup (Day 1, ~10 minutes)

1. Install Python 3.10+ if you don't have it: https://www.python.org/downloads/
   (tick "Add Python to PATH" during install)
2. Open the `smt_dashboard` folder in VS Code.
3. Open a terminal in VS Code (Terminal → New Terminal) and run:
   ```
   pip install -r requirements.txt
   ```
4. Start the server:
   ```
   python app.py
   ```
   You'll see `Running on http://0.0.0.0:5000`. Leave this terminal open —
   closing it stops the dashboard.
5. On the same computer, open a browser to **http://127.0.0.1:5000** — you
   should see the dashboard using the example data.

## 2. View it on your phone (same WiFi as the laptop)

1. On the laptop, find its WiFi IP address:
   - Windows: open Command Prompt, run `ipconfig`, look for "IPv4 Address"
     under your WiFi adapter (looks like `192.168.1.xx`).
2. On your phone (connected to the **same WiFi**), open a browser and go to:
   ```
   http://192.168.1.xx:5000
   ```
   (use the actual IP number from step 1)
3. Optional: add it to your phone's home screen (Share → Add to Home Screen)
   so it opens like an app.

> If your phone can't connect: your laptop's firewall may be blocking port
> 5000. On Windows, allow Python through "Windows Defender Firewall" for
> Private networks, or temporarily disable it to confirm that's the cause.

## 3. Enter your real data (Day 1–2)

Open `data/SMT_Dashboard_Data.xlsx` in Excel. There's a **READ ME - Legend**
tab explaining every sheet. In short:

| Tab | What it drives on the dashboard |
|---|---|
| `Lines` | The list of lines and their tabs at the top of the dashboard |
| `DayPlan` | The Overview KPI cards + Day Plan vs Actual table |
| `HourlyOutput` | The "Hourly Output — All Lines" graph |
| `MounterDetails` | Mounter Details table on each line's tab |
| `AOIDetails` | AOI Details table (First Pass Yield % is auto-calculated) |
| `UPH_Hourly` | The hourly UPH bar chart on each line's tab |
| `SolderPaste` | Solder Paste Timing table |
| `StencilCleaning` | Stencil Cleaning Timing table |

Yellow rows are examples — replace them with real rows (add new rows for
each new date, don't delete history). Keep `Line_Name` spelled identically
everywhere (e.g. always `SMT-L1`).

**Save the Excel file (Ctrl+S).** The dashboard re-reads it automatically —
just refresh the browser or wait for the 60-second auto-refresh. No need to
restart `app.py` or close Excel.

## 4. Showing your manager

- Keep the laptop running `python app.py` and connected to WiFi.
- On your phone, open the dashboard URL (or tap the home-screen icon you
  added). Use the date picker top-right to show any day you have data for.
- Tabs across the top: **Overview** (all lines) and one tab per line from
  the `Lines` sheet.

## 5. Host it on GitHub + Render (access from anywhere, no laptop needed)

This makes the dashboard live at a permanent URL (e.g.
`https://smt-dashboard.onrender.com`) that works on any phone, anywhere,
without your laptop needing to stay on.

### One-time setup

1. **Create the GitHub repo**
   - Go to https://github.com → New repository → name it `smt-dashboard` →
     Create (keep it Private if your data is sensitive).
   - In VS Code terminal, inside the `smt_dashboard` folder:
     ```
     git init
     git add .
     git commit -m "Initial dashboard"
     git branch -M main
     git remote add origin https://github.com/<your-username>/smt-dashboard.git
     git push -u origin main
     ```
     (VS Code will prompt you to sign in to GitHub the first time.)

2. **Deploy on Render**
   - Go to https://render.com → sign up with GitHub.
   - New → Web Service → pick your `smt-dashboard` repo.
   - Render auto-detects the `Procfile` and `requirements.txt` — leave
     settings as default → Create Web Service.
   - Wait ~2 minutes for the first build. You'll get a URL like
     `https://smt-dashboard.onrender.com` — that's your permanent link.
   - Free tier note: the service sleeps after 15 min idle and takes ~30–50
     seconds to wake on the next visit. Fine for a manager checking it a
     few times a day; upgrade to a paid plan if you need instant loads.

### Daily routine: updating the data

Every time you fill in new numbers in `data/SMT_Dashboard_Data.xlsx`:

1. Save the Excel file.
2. In VS Code terminal:
   ```
   git add data/SMT_Dashboard_Data.xlsx
   git commit -m "Update data"
   git push
   ```
3. Render redeploys automatically (~1 min) and the live site updates.

That's a few extra seconds each time vs. the laptop-WiFi version, but no
laptop needs to stay running, and it works from any network.

> Tip: create a tiny script or VS Code task that runs those three git
> commands with one click if typing them daily gets tedious — ask me and
> I'll add one.

## 5b. Easier alternative: PythonAnywhere (free, always-on, no sleep)

Unlike Render's free tier, PythonAnywhere's free "Beginner" account doesn't
sleep after inactivity — it's always reachable instantly. Setup is a bit
more manual but avoids Procfiles/gunicorn entirely.

### One-time setup

1. Push your code to GitHub first (see section 5, step 1, if not done yet).
2. Sign up free at https://www.pythonanywhere.com → "Create a Beginner account".
3. Open **Consoles** tab → **Bash** (starts a terminal in your browser).
4. Clone your repo and install dependencies:
   ```
   git clone https://github.com/<your-username>/smt-dashboard.git
   cd smt-dashboard
   mkvirtualenv --python=/usr/bin/python3.10 smt-env
   pip install -r requirements.txt
   ```
   (`mkvirtualenv` both creates and activates it — if it's not active later,
   run `workon smt-env`.)
5. Go to the **Web** tab → **Add a new web app** → **Next** → choose
   **Manual configuration** (not "Flask") → pick the same Python version
   you used above → **Next**.
6. On the Web tab page that appears, set:
   - **Virtualenv**: `/home/<your-username>/.virtualenvs/smt-env`
   - **Source code**: `/home/<your-username>/smt-dashboard`
   - **Static files** (optional, faster static loading): URL `/static/` →
     Directory `/home/<your-username>/smt-dashboard/static`
7. Click the **WSGI configuration file** link (same page) and replace its
   contents with:
   ```python
   import sys
   path = '/home/<your-username>/smt-dashboard'
   if path not in sys.path:
       sys.path.append(path)
   from app import app as application
   ```
   Save the file.
8. Back on the Web tab, click the big green **Reload** button.
9. Your dashboard is live at `https://<your-username>.pythonanywhere.com`
   — works on any phone, anywhere, immediately (no wake-up delay).

### Daily routine: updating the data

1. Edit and save `data/SMT_Dashboard_Data.xlsx` locally.
2. Push it: `git add data/SMT_Dashboard_Data.xlsx && git commit -m "Update data" && git push`
3. In the PythonAnywhere Bash console: `cd smt-dashboard && git pull`
4. Go to the **Web** tab and click **Reload** (PythonAnywhere doesn't
   auto-redeploy on file change like Render does — this manual reload step
   is the only extra step vs. Render).

### Free tier limits worth knowing

- One web app per free account (fine — you only need this one).
- No custom domain on free tier (your URL stays `*.pythonanywhere.com`).
- Limited daily CPU seconds — a low-traffic dashboard like this stays well
  within it.

## Notes / next steps if you want to extend it later

- To add a new line: just add a row to the `Lines` sheet and matching rows
  in the other sheets — a new tab appears automatically, no code changes.
- To run this on a proper always-on server instead of your laptop, ask
  whoever manages your factory IT — the Flask app can be deployed to any
  internal server without changing the frontend.
- `build_excel.py` only needs to be run again if you want to regenerate a
  **blank** template — don't run it on your real data file, it will
  overwrite it.
